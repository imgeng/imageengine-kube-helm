# Troubleshooting

Common failure modes, what they look like, and how to fix them. Symptom-driven — find the section that matches what you're seeing, then run the diagnostic and apply the fix.

The examples below assume you followed [GETTING_STARTED.md](GETTING_STARTED.md) and installed into the `imageengine` namespace with release name `imageengine-kube` (so resources are named `imageengine-kube-*`). If you used different names, adjust `-n imageengine` and the resource names accordingly.

If you're stuck, the [commands cheatsheet](#commands-cheatsheet) at the bottom covers the kubectl/helm one-liners you'll use most.

---

## LoadBalancer service stays `<pending>`

**Symptom:**

```
$ kubectl get svc -n imageengine -l 'app=imageengine-kube,tier=edge'
NAME                                TYPE           EXTERNAL-IP    ...
imageengine-kube-edge   LoadBalancer   <pending>      ...
```

By default the chart creates the edge as a `Service type: LoadBalancer`. If nothing in the cluster knows how to satisfy that, the service sits in `<pending>` forever.

**Diagnose:**

```bash
kubectl describe svc -n imageengine imageengine-kube-edge
```

Look at the events at the bottom.

**Fix:** pick the option that matches your environment.

- **Managed cloud (EKS / GKE / AKS / DOKS / LKE):** the cloud's LB controller should be running by default. Check that you didn't accidentally set IAM/RBAC restrictions that block it. Confirm `provider:` is set in your values file so the right preset is applied.
- **Self-managed / bare metal:** install MetalLB (or front the cluster with an external LB). See [providers/CUSTOM.md](providers/CUSTOM.md).
- **Don't want a LoadBalancer at all:** set `service.type: ClusterIP` (and pair it with `ingress.enabled: true` if you want external access via your own ingress controller). See [How do I configure the edge Service?](CUSTOMIZATIONS.md#how-do-i-configure-the-edge-service) in the customizations doc.

---

## Every pod stuck in `ImagePullBackOff` / `ErrImagePull`

**Symptom:**

```
$ kubectl get pods -n imageengine
NAME                                          READY   STATUS             ...
imageengine-kube-edge-...         0/1     ImagePullBackOff   ...
imageengine-kube-backend-...      0/1     ErrImagePull       ...
```

**Diagnose:**

```bash
kubectl describe pod -n imageengine <one of the failing pods>
```

Look for messages like `pull access denied` or `unauthorized`.

**Fix:**

Confirm the image-pull secret exists in the install namespace:

```bash
kubectl get secret ie-kube-image-pull -n imageengine
```

If missing, create it (see [GETTING_STARTED.md](GETTING_STARTED.md) step 2). If present but pull is still failing, the credentials are wrong — recreate it with the correct ImageEngine API key as the password:

```bash
kubectl delete secret ie-kube-image-pull -n imageengine
kubectl create secret docker-registry ie-kube-image-pull -n imageengine \
  --docker-server=https://docker.scientiamobile.com/v2/ \
  --docker-username=<your-email> \
  --docker-password=<your-api-key> \
  --docker-email=<your-email>
```

If you renamed the secret via `secrets.imagePullSecretName`, the secret name in the namespace must match.

---

## Edge or backend in `CrashLoopBackOff` mentioning auth / API key

**Symptom:** Pod restarts repeatedly. `kubectl logs` shows messages about authentication failures, missing API key, or "subscription not active."

**Fix:**

1. Confirm the API key secret exists and has a `KEY` field:
  ```bash
   kubectl get secret ie-kube-api-key -n imageengine -o jsonpath='{.data.KEY}' | base64 -d
  ```
2. Confirm the value matches the API key from your ImageEngine Control Panel.
3. Confirm your ImageEngine Kube subscription or trial is active in the Control Panel — if not, the API rejects the key even if it's syntactically valid.

If the secret is wrong, recreate it:

```bash
kubectl delete secret ie-kube-api-key -n imageengine
kubectl create secret generic ie-kube-api-key -n imageengine --from-literal=KEY=<your-api-key>
kubectl rollout restart deploy -n imageengine -l app=imageengine-kube
```

---

## OSC PVC stuck in `Pending`

OSC runs as a StatefulSet of cache shards, so there is one PVC per shard, named
`osc-storage-imageengine-kube-osc-<N>` (one per ordinal `osc-0`, `osc-1`, ...).

**Symptom:**

```
$ kubectl get pvc -n imageengine
NAME                                       STATUS    ...   STORAGECLASS       ...
osc-storage-imageengine-kube-osc-0  Pending   ...   <unset>            ...
```

**Diagnose:**

```bash
kubectl describe pvc -n imageengine osc-storage-imageengine-kube-osc-0
```

Common causes:

- No StorageClass exists with the requested name (or no default StorageClass is marked).
- The provisioner for that StorageClass isn't running.
- No worker node has enough free space for the requested PVC size.

**Fix:**

- If you set `provider:`, the right preset class is picked automatically — make sure the cluster actually has that StorageClass:
  ```bash
  kubectl get storageclass
  ```
  On **EKS** this is the usual culprit: `provider: aws` requests `gp3`, but EKS doesn't create a `gp3` StorageClass by default (you typically only get a legacy `gp2`). Create one — see [providers/AWS.md → Storage](providers/AWS.md#storage) for the exact manifest (the provisioner differs between Auto Mode and standard EKS) — or override to the class you already have.
- Otherwise set it explicitly:
  ```yaml
  objectStorageCache:
    persistence:
      storageClass: "my-csi-class"
      size: "100Gi"
  ```
- If you're on bare metal with no CSI yet, install one (local-path-provisioner is the simplest — see [providers/CUSTOM.md](providers/CUSTOM.md)).

---

## An OSC shard restarted / rescheduled

**This is expected and self-healing — usually no action needed.** OSC shards are
designed to be movable. When a shard pod is rescheduled it reattaches the same
volume (in its AZ), and during the brief gap the clients consistent-hash that
shard's keys onto the survivors. The only effect is that ~`1 / replicaCount` of
*cache-miss* traffic recomputes from origin for a few seconds; end users still
get their images (the backend re-routes through the fetcher/processor, and the
write-back to OSC is async). No client restart is required — the stable headless
DNS name plus the OSC client's reconnect/retry pick up the new pod IP
automatically.

You only need to investigate if a shard is stuck not-`Ready` (check its PVC
binding above, node capacity, and `kubectl describe pod`), or if many shards
churn at once (check node health and that `objectStorageCache.pdb.enabled` is
true so voluntary disruptions cycle one shard at a time).

---

## 502 Bad Gateway from the edge

**Symptom:** `curl` against the edge returns 502, or `imageengine_edge_responses_total{code="502"}` is rising.

**What a 502 means:** ImageEngine uses 502 for one thing, **your origin failed**. Neither the edge nor Varnish ever answers 502 for its own failures: the edge uses 503 (Varnish unavailable or edge overloaded), 504 (Varnish too slow) and 499 (client went away), and Varnish answers a failed backend fetch with 503. A 502 is passed on from the backend, which returns it when the origin fetch fails. Your site's users and crawlers can request URLs your origin can't serve, for example malformed query strings, so some 502s are normal and not a problem with the install.

**Diagnose:** look at `x-origin-status` and `x-origin-reason` on the 502:

```bash
curl -s -o /dev/null -D - "https://<your-host>/<path-that-fails>" | grep -i '^x-origin-'
```

| `x-origin-status` | Meaning | Where to look |
|---|---|---|
| `500`-`599` | The origin answered with that error | Your origin's logs, for that URL |
| `300`-`399` | The origin sent a redirect that can't be followed (no `Location`, `304`, …) | Your origin |
| `1` | Couldn't connect to the origin: refused, reset, TLS failure, too many redirects | Origin reachability from the cluster's egress, firewall allowlists |
| `3` | The origin didn't answer in time | Origin response time |
| `5` | The origin resolves or redirects to a private IP address, which is blocked | Origin DNS, or `IE_ORIGINFETCHER_ALLOWED_PRIVATE_NETWORKS` if that's intended |
| `6` | The origin's hostname didn't resolve | Origin DNS. If the reason says `server misbehaving` or `i/o timeout`, check the cluster's DNS instead |
| `0` | The origin connection failed part-way through the response | Origin, then fetcher logs |

**Failures of the install are not 502s.** With edge image 4.10.5 and later, a 502 that the install produced for its own failure is answered by the edge as 503 or 504, so it lands in your 5xx alert rather than your origin alert. The `x-origin-*` headers stay on the response, and `imageengine_edge_upstream_502_total{to,reason}` counts every 502 the edge received from the install, by the status it answered (`to`) and why (`reason`):

| `reason` | `to` | What happened | Where to look |
|---|---|---|---|
| `customer_origin` | 502 | One of the `x-origin-status` values in the table above | Your origin |
| `no_origin_status` | 503 | No `x-origin-status`. With `x-origin-reason: origin-fetcher http client error: [...]`, the backend couldn't get an answer from the fetcher. With no `x-origin-*` headers at all and an HTML error body, something between Varnish and the backend made its own 502; Varnish doesn't | Fetcher pods `Ready` and not restarting (`kubectl get pods -n imageengine`, `kubectl logs -n imageengine deploy/imageengine-kube-fetcher`) and `imageengine_backend_fetch_errors_total`; any proxy or load balancer in front of a remote backend (`varnish.ieBackends`); backend pods restarting mid-request |
| `backend_timeout` | 504 | The backend's own wait for the fetcher ran out (`Client.Timeout` in `x-origin-reason`): either the origin is very slow or the fetcher is saturated | Origin response time; fetcher load |
| `imageengine_failure` | 503 | `x-origin-status: 4`: the fetcher's queue for that origin is full, so it is shedding load (`imageengine_fetcher_queue_full_total`), usually one slow origin with a burst of requests. `x-origin-status: 2`: the origin served a TIFF and converting it through the processor failed | Add fetcher replicas or see the fetcher section of [SIZING.md](SIZING.md); processor health and logs |

Edge images before 4.10.5 pass all of these on as 502; the same `x-origin-*` headers tell them apart.

If all your origins return 502 at once, suspect the install (fetcher, backend, egress or DNS) before suspecting every origin.

**Alerting:** alert on 502 separately from other 5xx. Leave `code="502"` out of a general 5xx alert, so your origin's errors don't page you as an outage, and use a separate, less sensitive alert for 502 that says it is about origin errors. For example:

```promql
# ImageEngine 5xx, excluding origin errors
sum(rate(imageengine_edge_responses_total{code=~"5..", code!="502"}[5m]))
# Origin errors
sum(rate(imageengine_edge_responses_total{code="502"}[5m]))
```

---

## Every client shares one fair-share bucket

**Symptom:** under real traffic `imageengine_edge_clients_tracked` stays near the number of nodes or load balancer addresses, and busy periods produce `imageengine_edge_reject_total{reason="fair_share"}` for everyone at once. Or the access log shows node or load balancer IPs as the client.

**Diagnose:**

```bash
kubectl port-forward -n imageengine deploy/imageengine-kube-edge 9464:9464 &
curl -s localhost:9464/metrics | grep -E 'clients_tracked|client_ip_resolutions_total'
kubectl get deploy -n imageengine imageengine-kube-edge -o yaml | grep -A1 -E 'EDGE_(CLIENT_IP_SOURCE|PROXY_PROTOCOL|XFF_TRUSTED_HOPS|TRUSTED_PROXIES)'
```

**Fix:** the edge is not getting the client's address from the path your traffic takes. See [How do I preserve the client IP?](CUSTOMIZATIONS.md#how-do-i-preserve-the-client-ip):

- No `client_ip_resolutions_total` series at all: the edge is in `legacy` mode, because `clientIP.mode` is `legacy` or `images.edge` is older than 4.10.0.
- Mostly `remote_addr` but the IPs are nodes: nothing delivers the client's address. Behind a load balancer that supports PROXY protocol, use `clientIP.mode: proxyProtocol` (and on a `custom` provider add your load balancer's annotation to `service.annotations`). Otherwise set `service.externalTrafficPolicy: Local`.
- `short_forwarded`: fewer `X-Forwarded-For` entries arrive than `clientIP.forwardedHops`. Lower it.
- Mostly `forwarded` but the IPs belong to your CDN or load balancer: there is one more proxy than `forwardedHops` counts. Raise it by one.
- `untrusted_peer`: `clientIP.trustedProxies` does not include the address your ingress controller connects from.

---

## Requests fail after switching to `proxyProtocol`

**Symptom:** after enabling `clientIP.mode: proxyProtocol`, some or all requests get `400 Bad Request` or the connection is reset.

- **400 during a rollout:** the load balancer already sends PROXY headers but some edge pods were started before the change and do not expect them. It clears when the rollout finishes; next time, upgrade in two steps with `clientIP.proxyProtocol.annotateService` (see [CUSTOMIZATIONS.md](CUSTOMIZATIONS.md#how-do-i-preserve-the-client-ip)).
- **Connections reset with `policy: required`:** the load balancer is not sending headers, so the annotation did not take effect. Check it on the Service (`kubectl get svc -n imageengine imageengine-kube-edge -o yaml`) and in your provider's console, or go back to `policy: optional`.
- **400 from a load balancer you configured yourself:** it sends PROXY headers to an edge in another mode. Set `clientIP.mode: proxyProtocol` to match.

---

## 504 Gateway Timeout / very slow first request

**Symptom:** First request for a given URL takes 2+ seconds and sometimes times out. Subsequent requests for the same URL are fast.

This is a cache miss path — fetcher pulls the original from your origin, processor transforms it, OSC writes it to disk, then the response comes back through varnish and edge. If your origin is slow or unreachable, the whole chain stalls.

Who answered tells you where the wait ran out:

- **`504` with body `upstream timeout`:** the edge waited `EDGE_VARNISH_RESPONSE_TIMEOUT` (75s by default) for Varnish. The image is usually still being fetched and processed, and is cached when it finishes, so retrying the same URL is often fast.
- **`502` with `x-origin-status` / `x-origin-reason`:** the origin failed or timed out within that wait; the headers say why.
- **A `504` sooner than 75s, or one from your load balancer or ingress:** something in front of the edge has a shorter timeout and cut the request off. Common defaults are shorter than the edge's 75s: AWS ALB idle timeout 60s, GCE Ingress backend timeout 30s, ingress-nginx `proxy-read-timeout` 60s, Envoy Gateway route timeout 15s. The chart already sets 75s where it creates the resource: the `aws` preset's ALB Ingress (`idle_timeout.timeout_seconds=75`) and the HTTPRoute (`httpRoute.timeouts.request: 75s`). For anything else, raise its timeout to at least `EDGE_VARNISH_RESPONSE_TIMEOUT`, for example:
  ```yaml
  ingress:
    annotations:
      # ingress-nginx
      nginx.ingress.kubernetes.io/proxy-read-timeout: "75"
      nginx.ingress.kubernetes.io/proxy-send-timeout: "75"
  ```
  On GKE, attach a `BackendConfig` with `timeoutSec: 75` to the edge Service. If you set `alb.ingress.kubernetes.io/load-balancer-attributes` yourself (for example to turn on access logs), it replaces the preset's value, so include `idle_timeout.timeout_seconds=75` in it.

**Diagnose:**

```bash
kubectl logs -n imageengine deploy/imageengine-kube-fetcher --tail=100
```

Look for connection errors, timeouts, or DNS resolution failures pointing at your origin.

**Fix:**

- Confirm origin reachability from inside the cluster:
  ```bash
  kubectl run -it --rm dnsutils -n imageengine --image=busybox --restart=Never -- \
    wget -O- http://your-origin.example.com/path/to/image.jpg
  ```
- If your origin is fine but timeouts happen under load, raise:
  ```yaml
  fetcher:
    env:
      IE_ORIGINFETCHER_FETCHER_CLIENT_DIAL_TIMEOUT: "30s"
  ```
- For genuinely slow origins, scale the fetcher (`replicaCount` or `autoscaling`).

---

## Processor latency rising even with HPA enabled

**Symptom:** Processor pods are at maxReplicas, CPU is pinned at 100%, response latency keeps growing.

**Fix:**

The HPA can only add pods up to `maxReplicas`. Either raise it:

```yaml
processor:
  autoscaling:
    enabled: true
    minReplicas: 4
    maxReplicas: 32         # was 16
    targetCPUUtilizationPercentage: 80
```

…or give each pod more CPU headroom:

```yaml
processor:
  resources:
    requests:
      cpu: "2"
    limits:
      cpu: "4"
```

If you have spare CPU per pod but throughput is still low, raise the per-core thread count:

```yaml
processor:
  env:
    IE_PROCESSOR_PROCESSINGTHREADS_PER_CORE: "1.5"
```

See [SIZING.md](SIZING.md) for why processor saturation is the most common bottleneck.

---

## Image processing fails on very large origin images

**Symptom:** Specific large originals (50+ MP photos, multi-page TIFFs, etc.) return errors or 5xx responses while smaller images on the same origin work fine.

**Fix:**

libvips streams large images to disk to avoid blowing through pod memory. The threshold defaults to 10 GiB; lower it to push more images through the disk path:

```yaml
processor:
  env:
    IE_PROCESSOR_VIPS_DISC_THRESHOLD: "5g"
```

Also confirm the processor pod has enough ephemeral storage in its `resources.limits`.

---

## Ingress returns 404 even though the service is up

**Symptom:** `curl` directly against the LoadBalancer external IP works. `curl` against your hostname returns 404.

**Diagnose:**

```bash
kubectl get ingress -n imageengine
kubectl describe ingress -n imageengine imageengine-kube-ingress
```

**Fix:**

Two things to check:

1. **The hostname must match.** The chart creates a rule per host listed in `ingress.hosts`. A request with a `Host:` header that's not in that list will hit the ingress controller's default backend and 404.
2. `**ingress.className` must match what's actually installed.** If your cluster has Traefik but `ingress.className: gce` was rendered (e.g. you set `provider: gke` but installed Traefik), the GCE controller is the one that's supposed to handle the Ingress and it's not there.

Fix:

```yaml
ingress:
  enabled: true
  className: traefik              # match the controller you actually installed
  hosts:
    - images.example.com          # must match the Host header on incoming requests
```

---

## Ingress never gets an ADDRESS

**Symptom:** `kubectl get ingress` shows your Ingress but the `ADDRESS` column stays empty, and nothing routes to it. `kubectl describe ingress <name>` shows an event like `ingressClass 'traefik' not found` (or no events at all).

**Cause:** No controller is watching the Ingress. Either its class names a controller that isn't installed, or it has no class and the cluster has no default IngressClass. The chart leaves the class unset on `azure`, `digitalocean`, `linode` and `custom`, so the Ingress waits for a default. On **EKS Auto Mode**, the preset's `alb` is the only controller, so an Ingress with any other class sits orphaned.

**Diagnose:**

```bash
kubectl get ingressclass                          # which classes/controllers actually exist (cluster-scoped)
kubectl describe ingress -n imageengine imageengine-kube-ingress
```

**Fix:** make `ingress.className` match a class that exists, or mark your controller's IngressClass as the default (`ingressclass.kubernetes.io/is-default-class: "true"`). On EKS (`provider: aws`) the preset already defaults to `alb`; if you pinned another class, remove that override or install that controller. See [providers/AWS.md](providers/AWS.md#exposing-the-edge--two-paths).

> Note: the chart's default exposure path on AWS is the LoadBalancer Service (NLB), which needs **no** Ingress controller at all. If you only need a public IP, leave `ingress.enabled: false`.

---

## HTTPRoute isn't accepted by the Gateway

**Symptom:** with `httpRoute.enabled: true`, requests through the Gateway get 404 or a connection reset, although the edge pods are healthy.

**Diagnose:**

```bash
kubectl get httproute -n imageengine imageengine-kube-httproute -o yaml   # status.parents[].conditions
kubectl get gateway -A                                                   # the Gateway exists and is Programmed
```

**Fix**, by the condition that is not `True`:

- **No `status.parents` entry at all:** no controller owns the Gateway in `httpRoute.parentRefs`. Check the `name` and `namespace` (the namespace defaults to the release's).
- **`Accepted: False`, reason `NotAllowedByListeners`:** the listener's `allowedRoutes.namespaces` doesn't include the release's namespace. Allow it on the Gateway.
- **`Accepted: False`, reason `NoMatchingListenerHostname`:** none of `httpRoute.hostnames` matches the listener's `hostname`. Fix one or the other.
- **`ResolvedRefs: False`:** the route can't reach the edge Service. Check that the release installed it (`kubectl get svc -n imageengine`).

---

## An edge roll stalls with one new pod missing

With Edge Warm Start (`edge.warmStart.enabled`) the edge rolls out surge-only: Kubernetes creates the new pod before it removes an old one. If a ResourceQuota on the namespace has no room for that extra pod, the ReplicaSet can't create it, no old pod is removed, and the roll waits forever.

**Diagnose:**

```bash
kubectl get events -n imageengine --sort-by=.lastTimestamp | grep -i quota
kubectl describe resourcequota -n imageengine
```

A `FailedCreate` event says `exceeded quota`.

**Fix:** give the quota room for one more edge pod (its requests and limits, for example 250m CPU, 768Mi requested and 1Gi limit), or lower `edge.replicaCount` by one.

## Edge Warm Start didn't warm a new edge

With Edge Warm Start (`edge.warmStart.enabled`), a new edge should copy its peers' width cache at start. `imageengine_edge_kvcache_bootstrap_total{result}` says what happened:

| `result` | Meaning |
| --- | --- |
| `ok` | It copied a peer's whole cache. |
| `partial` / `timeout` | It got part of it within 15 s; the rest is fetched in the background once the pod is Ready. |
| `local_only` | No peer answered, but it loaded its own snapshot (a restarted container). |
| `no_peer` | No other edge was Ready. Normal for the first edge of a release, and when every edge restarts at once. |
| `error` | Its peers didn't answer. Expected on the first roll after enabling sync, when the old edges don't share their caches yet. |
| `incompatible` | The peers run an edge version with another cache format. Normal during a roll that changes it. |

If every new edge reports `error` or `no_peer` outside those cases, check that the peers Service lists the edges and that the edges can reach each other on port 9464 (a NetworkPolicy):

```bash
kubectl get endpointslices -n imageengine -l kubernetes.io/service-name=<release>-edge-peers
kubectl logs -n imageengine deploy/<release>-edge | grep natural-width
```

## Edge CPU high while its memory looks fine

**Symptom:** edge pods use one or more CPU cores each at ordinary traffic, latency rises, and other pods on the same nodes slow down, but the edges aren't near their memory limit and aren't restarting.

**Cause:** the edge's garbage collector is running almost continuously. The edge keeps its Go memory below a limit derived from `edge.resources.limits.memory`; when the live heap (mostly a full natural-width store) is close to that limit, every collection frees little and the next one starts at once. Serving a peer's start-up copy under Edge Warm Start adds enough to tip a tight edge over.

**Diagnose:** compare the edge's Go memory limit with its live heap, and look at its collection rate:

```bash
kubectl port-forward -n imageengine pod/<edge-pod> 9464:9464 &
curl -s localhost:9464/metrics | grep -E '^(go_gc_gomemlimit_bytes|go_memstats_heap_alloc_bytes|go_gc_duration_seconds_count|imageengine_edge_kvcache_(entries|capacity)|imageengine_edge_memlimit_)'
```

A limit less than about twice the heap, with `go_gc_duration_seconds_count` rising by several per second, is this problem. Edge 4.13.0 and later also export the limit's inputs (`imageengine_edge_memlimit_*`); `imageengine_edge_memlimit_floored` at 1 means the edge fell back to a quarter of the container limit.

**Fix:** raise `edge.resources.limits.memory` or lower `edge.env.EDGE_WIDTH_CACHE_SIZE` until the store fits as in [SIZING.md](SIZING.md#edge-memory-and-the-natural-width-store); the chart refuses combinations that don't. As a stopgap, a pod's memory limit can be raised in place (`kubectl patch pod <edge-pod> --subresource resize`, Kubernetes 1.33 and later) and the edge picks it up within a minute, without a restart. Edge 4.12.x can also be misled by transparent huge pages on the node; edge 4.13.0 and later turn them off for the edge process.

## Pods evicted under load / nodes OOM

**Symptom:** `kubectl get events` shows pod evictions or OOMKilled under traffic.

**Diagnose:**

```bash
kubectl get events -n imageengine --sort-by=.lastTimestamp | tail -30
kubectl top pods -n imageengine
kubectl top nodes
```

**Fix:**

**Edge OOMKilled after running for days**, with a restart count but no traffic spike: its natural-width store has filled towards `EDGE_WIDTH_CACHE_SIZE` and no longer fits `edge.resources.limits.memory`. Check `imageengine_edge_kvcache_entries` against `imageengine_edge_kvcache_capacity`, then lower the size or raise the limit as in [SIZING.md](SIZING.md#edge-memory-and-the-natural-width-store) (about 340 MiB + 2 × (60 MiB + 106 bytes per entry), within 90% of the limit).

Most often this is backend memory or processor CPU. Backend buffers full images in memory between layers — if the limit is too tight it OOMs exactly when traffic spikes. Don't trim backend memory:

```yaml
backend:
  resources:
    requests:
      memory: "2Gi"
    limits:
      memory: "8Gi"
```

For processor, raise CPU requests so the kernel doesn't squeeze it under contention:

```yaml
processor:
  resources:
    requests:
      cpu: "1"
```

See [SIZING.md](SIZING.md) for per-component characteristics.

---

## Commands cheatsheet

```bash
# All chart-managed pods
kubectl get pods -n imageengine -l app=imageengine-kube -o wide

# Live tail any deployment
kubectl logs -f -n imageengine deploy/imageengine-kube-edge
kubectl logs -f -n imageengine deploy/imageengine-kube-backend
kubectl logs -f -n imageengine deploy/imageengine-kube-fetcher
kubectl logs -f -n imageengine deploy/imageengine-kube-processor
kubectl logs -f -n imageengine deploy/imageengine-kube-osc

# What helm thinks the release looks like
helm list -n imageengine
helm get values imageengine-kube -n imageengine
helm get manifest imageengine-kube -n imageengine | less

# Render the chart locally without installing (great for diffing values changes)
helm template imageengine-kube imageengine/imageengine-kube -f imageengine-values.yaml

# Force rollout after secret changes (deployments don't auto-restart on secret edits)
kubectl rollout restart deploy -n imageengine -l app=imageengine-kube

# Quick resource view
kubectl top pods -n imageengine
kubectl top nodes
```

## Next

- [SIZING.md](SIZING.md) — when the fix is "give it more resources."
- [CUSTOMIZATIONS.md](CUSTOMIZATIONS.md) — exact override syntax for every knob mentioned above.
- Your provider doc — when the issue is platform-specific (LB controller, storage class, ingress controller): [AWS](providers/AWS.md), [Azure](providers/AZURE.md), [DigitalOcean](providers/DIGITALOCEAN.md), [GKE](providers/GKE.md), [Linode](providers/LINODE.md), [self-managed](providers/CUSTOM.md).

