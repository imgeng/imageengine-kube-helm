# ImageEngine Kube

Helm chart that deploys the ImageEngine image-optimization platform on Kubernetes. Published to `https://kube.imageengine.io/charts`.

For anything beyond the quick-start below, head to the [docs/](docs/) folder.

## Quick start

1. **Add the Helm repository**
   ```bash
   helm repo add imageengine https://kube.imageengine.io/charts
   helm repo update
   ```

2. **Create the two required secrets** (the chart does not create these for you — they must exist before `helm install`):
   ```bash
   kubectl create secret generic ie-kube-api-key \
     --from-literal=KEY=<your-api-key>

   kubectl create secret docker-registry ie-kube-image-pull \
     --docker-server=https://docker.scientiamobile.com/v2/ \
     --docker-username=<your-email> \
     --docker-password=<your-api-key> \
     --docker-email=<your-email>
   ```
   You need an **active** ImageEngine Kube subscription to mint the API key.

3. **Write a minimal `imageengine-values.yaml`** — `provider:` is the only must-have:
   ```yaml
   provider: aws

   ingress:
     enabled: true
     hosts:
       - images.example.com
   ```

4. **Install**
   ```bash
   helm install imageengine imageengine/imageengine-kube -f imageengine-values.yaml
   ```

5. **Verify** — pods should settle within a minute or two, and the LoadBalancer service gets an external IP from your cloud provider:
   ```bash
   kubectl get pods
   kubectl get svc -l app=imageengine-kube
   ```

For the full step-by-step including a smoke-test `curl`, see [docs/GETTING_STARTED.md](docs/GETTING_STARTED.md).

## Provider presets

Setting `provider:` auto-configures the right storage class and ingress class for that platform. Explicit values in your file always take precedence. Cloud-LB-specific annotations (LB name, NLB type, scheme, etc.) live under `service.annotations` — see your [provider doc](docs/providers/) for the right keys.

| Provider | Storage Class | Ingress Class | Doc |
|----------|--------------|---------------|-----|
| `aws` | `gp3` | `nginx` | [docs/providers/AWS.md](docs/providers/AWS.md) |
| `azure` | `managed-csi-premium` | `nginx` | [docs/providers/AZURE.md](docs/providers/AZURE.md) |
| `digitalocean` | `do-block-storage` | `nginx` | [docs/providers/DIGITALOCEAN.md](docs/providers/DIGITALOCEAN.md) |
| `gke` | `standard-rwo` | `gce` | [docs/providers/GKE.md](docs/providers/GKE.md) |
| `linode` | `linode-block-storage-retain` | `nginx` | [docs/providers/LINODE.md](docs/providers/LINODE.md) |
| `custom` | `standard` | `nginx` | [docs/providers/CUSTOM.md](docs/providers/CUSTOM.md) — bare metal, on-premise, self-managed |

## Upgrading

```bash
helm repo update
helm upgrade imageengine imageengine/imageengine-kube -f imageengine-values.yaml
```

To pin a specific chart version: `helm upgrade ... --version 1.2.3 -f imageengine-values.yaml`. List available versions with `helm search repo imageengine/imageengine-kube --versions`.

## Where to next

- [docs/GETTING_STARTED.md](docs/GETTING_STARTED.md) — full first-deployment walkthrough.
- [docs/REQUIREMENTS.md](docs/REQUIREMENTS.md) — Kubernetes version, storage, network, and compute minimums.
- [docs/SIZING.md](docs/SIZING.md) — recommended footprints for low / medium / high traffic.
- [docs/SCALING.md](docs/SCALING.md) — how the platform behaves under load.
- [docs/CUSTOMIZATIONS.md](docs/CUSTOMIZATIONS.md) — replicas, autoscaling, ingress, TLS, OSC sizing, Varnish tuning, and the rest.
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) — common issues and fixes.
- [docs/providers/](docs/providers/) — platform-specific guidance for AWS, Azure, DigitalOcean, GKE, Linode, and self-managed clusters.
