# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

A Helm chart (`imageengine-kube`) that deploys the ImageEngine image optimization platform on Kubernetes. This is a **customer-facing chart** published to `https://kube.scientiamobile.com/charts` — customers install it via `helm repo add`. All images are pulled from `docker.scientiamobile.com`.

## Common Commands

```bash
# Validate templates render correctly
helm template imageengine . -f values.yaml

# Validate with a specific provider
helm template imageengine . --set provider=aws

# Lint the chart
helm lint .

# Dry-run install against a cluster
helm install imageengine . --dry-run

# Package the chart for release
helm package .
```

## Architecture

### Traffic Flow

```
LoadBalancer -> edge:8080 -> varnish:8080 -> backend:8000 -> fetcher:8000 -> origin
                                                        -> processor:8000
                                                        -> osc:8000
```

### Components (6 deployments)

| Component | Tier label | Port | Role |
|-----------|-----------|------|------|
| **frontend** (2 containers: `edge` + `varnish`) | `frontend` | edge:8080, varnish:8080 | Go edge proxy (WURFL, admission, routing) + Varnish cache |
| **backend** | `backend` | 8000 | Request orchestrator — dispatches to fetcher, processor, and OSC |
| **fetcher** | `fetcher` | 8000 | Fetches original images from customer origins |
| **processor** | `processor` | 8000 | Image transformation (resize, format conversion via libvips) |
| **osc** (Object Storage Cache) | `object-storage` | 8000 | Persistent local cache with PVC; only stateful component |
| **rsyslog** | `logging` | 514 | Centralized syslog for all components; runs as root |

### Service Discovery

Components find each other via Helm-templated service names: `{{ include "imageengine.fullname" . }}-<component>`. The backend hardcodes connections to fetcher, processor, and OSC services. OSC sharding is not supported in this chart (`OSCCLIENT_ENVCONFIG=true`, single `OSC0_HOST`).

### Provider Preset System

Setting `provider: aws|digitalocean|linode|gke|azure|vultr` in values auto-configures storage class, ingress class, ingress annotations, external DNS provider, and load balancer name annotation. Explicit values always override presets. The resolution logic lives in `templates/_helpers.tpl`.

## Key Conventions

- **Image tags are centralized** in `values.yaml` under `images.*` (not per-component). All containers for a component share the same tag (e.g., edge and varnish both use `images.frontend`).
- **Secrets are referenced from pre-existing K8s secrets**, not created by the chart. Required secrets: `ie-kube-api-key` (always), `ie-kube-image-pull` (always), `ie-kube-fetcher` (optional, for S3/Wasabi origins).
- **Environment variables** from `values.yaml` are injected via `range $key, $value` loops at the bottom of each deployment's env block. Hardcoded/computed env vars come first in the template.
- **Identity values** (`values.identity.*`) are injected into every component as env vars for statistics/telemetry.
- **Security contexts**: backend, fetcher, and OSC run as nonroot (UID 65532). Frontend edge drops all capabilities. Varnish and processor need CHOWN/SETUID/SETGID. Rsyslog runs as root (needs NET_BIND_SERVICE for port 514).
- **Chart version** in `Chart.yaml` is the Helm chart release version; `appVersion` tracks the backend image version.
- The `untracked-files/` directory and `*.py` files are excluded from the Helm package (`.helmignore`).
