# Certificate Manager
### Copied from https://cert-manager.io/docs/tutorials/getting-started-aws-letsencrypt
### Create an IAM OIDC provider for your cluster
```
eksctl utils associate-iam-oidc-provider --cluster $CLUSTER --approve --region $REGION
```

### Create an IAM policy
```
aws iam create-policy \
     --policy-name eks-cert-manager-policy \
     --description "This policy allows cert-manager to manage ACME DNS01 records in Route53 hosted zones. See https://cert-manager.io/docs/configuration/acme/dns01/route53" \
     --policy-document file:///dev/stdin <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "route53:GetChange",
      "Resource": "arn:aws:route53:::change/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "route53:ChangeResourceRecordSets",
        "route53:ListResourceRecordSets"
      ],
      "Resource": "arn:aws:route53:::hostedzone/*"
    },
    {
      "Effect": "Allow",
      "Action": "route53:ListHostedZonesByName",
      "Resource": "*"
    }
  ]
}
EOF
```

### Create an IAM role and associate it with a Kubernetes service account
```
AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
eksctl create iamserviceaccount \
  --name cert-manager-sa \
  --namespace cert-manager \
  --cluster ${CLUSTER} \
  --role-name eks-cert-manager-role \
  --attach-policy-arn arn:aws:iam::${AWS_ACCOUNT_ID}:policy/eks-cert-manager-policy \
  --region us-east-2 \
  --approve
```

# External DNS

### Create IAM Policy for External DNS
```
aws iam create-policy \
  --policy-name eks-external-dns-policy \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "route53:GetChange",
            "Resource": "arn:aws:route53:::change/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "route53:ChangeResourceRecordSets",
                "route53:ListResourceRecordSets"
            ],
            "Resource": "arn:aws:route53:::hostedzone/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "route53:ListHostedZonesByName",
                "route53:ListHostedZones"
            ],
            "Resource": "*"
        }
    ]
}'
```

### Create IAM Role for External DNS and attach it to IAM Policy
```
eksctl create iamserviceaccount \
  --name external-dns-sa \
  --namespace kube-system \
  --cluster ${CLUSTER} \
  --role-name eks-external-dns-role \
  --attach-policy-arn arn:aws:iam::${AWS_ACCOUNT_ID}:policy/eks-external-dns-policy \
  --region us-east-2 \
  --approve
```