# ImageEngine Kube

## Prerequisites

Before installing ImageEngine Kube, you must create the required secrets in your Kubernetes cluster.

> **Note:** You must have an ImageEngine Kube subscription in the `ACTIVE` state to create an API Key in the ImageEngine Control Panel.

### 1. Create the API Key Secret

```bash
kubectl create secret generic ie-kube-api-key \
  --from-literal=KEY=<your-api-key>
```

### 2. Create the Image Pull Secret

```bash
kubectl create secret docker-registry ie-kube-image-pull \
  --docker-server=https://docker.scientiamobile.com/v2/ \
  --docker-username=<your-email> \
  --docker-password=<your-api-key> \
  --docker-email=<your-email>
```

## Configuration

Create a values file (e.g., `imageengine-values.yaml`) to store your configuration. This file documents your customizations, can be version-controlled, and simplifies upgrades.

Your values file only needs to contain settings you want to override.  `provider` should always be present:

```yaml
provider: aws

ingress:
  enabled: true
  hosts:
    - images.yourdomain.com

frontend:
  replicaCount: 2

backend:
  replicaCount: 2

processor:
  replicaCount: 2

fetcher:
  replicaCount: 2

objectStorageCache:
  persistence:
    size: "40Gi"
```

### Provider Presets

Setting the `provider` value automatically configures provider-specific defaults:

| Provider | Storage Class | Ingress Class | External DNS |
|----------|--------------|---------------|--------------|
| `aws` | `gp3` | `nginx` | `aws` |
| `digitalocean` | `do-block-storage` | `nginx` | `digitalocean` |
| `linode` | `linode-block-storage-retain` | `nginx` | `linode` |
| `gke` | `standard-rwo` | `gce` | `google` |
| `azure` | `managed-premium` | `nginx` | `azure` |
| `vultr` | `vultr-block-storage` | `nginx` | `vultr` |

Explicit values in your file always take precedence over provider presets.

### Additional Customization

Resource requests, limits, and component-specific settings can also be configured:

```yaml
frontend:
  replicaCount: 3
  resources:
    requests:
      memory: "2048Mi"
      cpu: "1"
      ephemeral-storage: "20Gi"
    limits:
      memory: "8192Mi"
      cpu: "4"
      ephemeral-storage: "100Gi"

backend:
  replicaCount: 4
  resources:
    requests:
      memory: "512Mi"
      cpu: "0.5"
```

See `values.yaml` for all available options.

## Installation

Add the ImageEngine Kube Helm repository:

```bash
helm repo add imageengine https://kube.scientiamobile.com/charts
helm repo update
```

View available chart versions:

```bash
helm search repo imageengine/imageengine-kube --versions
```

Install using your values file:

```bash
helm install imageengine imageengine/imageengine-kube -f imageengine-values.yaml
```

Install a specific version:

```bash
helm install imageengine imageengine/imageengine-kube --version 1.2.3 -f imageengine-values.yaml
```

> **Tip:** For quick testing, you can use `--set` flags instead of a values file:
> ```bash
> helm install imageengine imageengine/imageengine-kube \
>   --set provider=aws \
>   --set ingress.enabled=true \
>   --set ingress.hosts[0]=images.yourdomain.com
> ```

## Upgrading

Update the Helm repository to fetch the latest chart versions:

```bash
helm repo update
```

Upgrade to the latest version:

```bash
helm upgrade imageengine imageengine/imageengine-kube -f imageengine-values.yaml
```

Upgrade to a specific version:

```bash
helm upgrade imageengine imageengine/imageengine-kube --version 1.2.3 -f imageengine-values.yaml
```

## TLS/SSL

ImageEngine Kube does not provide its own SSL/TLS termination layer. TLS should be handled by your Kubernetes ingress controller or a load balancer in front of the cluster.
